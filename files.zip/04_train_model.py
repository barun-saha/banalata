"""
Step 4: Bengali GPT — Model Definition and Training
====================================================
Decoder-only transformer trained from scratch on Bengali literary text.

Architecture:
  - ~12M parameters (6 layers × 384 embed dim × 6 heads)
  - Causal self-attention using torch.nn.functional.scaled_dot_product_attention
    (PyTorch 2.0+: uses FlashAttention-style kernels automatically on CUDA)
  - RoPE positional encoding (better than learned positions for generalization)
  - RMSNorm instead of LayerNorm (faster, no learned bias)
  - Author-conditioning via special tokens at start of each work

Requirements:
    pip install torch==2.11.0 sentencepiece==0.2.1 numpy

Usage:
    python 04_train_model.py                   # train from scratch
    python 04_train_model.py --resume          # resume from latest checkpoint
"""

import argparse
import json
import math
import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class ModelConfig:
    vocab_size:     int   = 5000   # set from tokenizer at runtime
    context_len:    int   = 512    # max sequence length
    n_layer:        int   = 6
    n_head:         int   = 6
    n_embd:         int   = 384
    dropout:        float = 0.15   # higher than typical — small data needs it
    bias:           bool  = False  # no bias in linear layers (GPT-2 style)


@dataclass
class TrainConfig:
    # Paths
    data_dir:       str   = "data"
    tok_dir:        str   = "tokenizer"
    ckpt_dir:       str   = "checkpoints"

    # Training
    batch_size:     int   = 32
    max_iters:      int   = 12000
    grad_clip:      float = 1.0
    weight_decay:   float = 0.1

    # Learning rate schedule: linear warmup then cosine decay
    learning_rate:  float = 3e-4
    min_lr:         float = 3e-5
    warmup_iters:   int   = 600
    lr_decay_iters: int   = 12000   # = max_iters

    # Evaluation & checkpointing
    eval_interval:  int   = 300
    eval_iters:     int   = 60
    save_interval:  int   = 600
    patience:       int   = 8       # early stopping: iters without val improvement

    # Mixed precision — bfloat16 on Ampere+ GPUs, float16 otherwise
    dtype:          str   = "auto"  # "auto" | "bfloat16" | "float16" | "float32"

    # Sample during training to eyeball quality
    sample_interval:    int  = 600
    sample_max_tokens:  int  = 150


# ---------------------------------------------------------------------------
# Rotary Positional Encoding (RoPE)
# ---------------------------------------------------------------------------

def precompute_rope_freqs(head_dim: int, max_seq_len: int,
                           base: float = 10000.0) -> torch.Tensor:
    """
    Precompute complex rotation frequencies for RoPE.
    Returns tensor of shape (max_seq_len, head_dim // 2) as complex64.
    """
    theta = 1.0 / (base ** (torch.arange(0, head_dim, 2).float() / head_dim))
    positions = torch.arange(max_seq_len).float()
    freqs = torch.outer(positions, theta)           # (seq, head_dim//2)
    return torch.polar(torch.ones_like(freqs), freqs)   # complex


def apply_rope(x: torch.Tensor, freqs: torch.Tensor) -> torch.Tensor:
    """
    Apply RoPE to query or key tensor.
    x:     (batch, n_heads, seq_len, head_dim)
    freqs: (seq_len, head_dim // 2)  complex
    """
    # Reshape x to complex pairs
    x_complex = torch.view_as_complex(x.float().reshape(*x.shape[:-1], -1, 2))
    freqs     = freqs[:x.shape[2]]   # trim to actual seq len
    # Broadcast over batch and heads
    freqs     = freqs.unsqueeze(0).unsqueeze(0)  # (1, 1, seq, head_dim//2)
    x_rotated = x_complex * freqs
    return torch.view_as_real(x_rotated).reshape(x.shape).to(x.dtype)


# ---------------------------------------------------------------------------
# RMSNorm
# ---------------------------------------------------------------------------

class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps   = eps
        self.scale = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        norm = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
        return norm * self.scale


# ---------------------------------------------------------------------------
# Causal Self-Attention (using F.scaled_dot_product_attention — PyTorch 2.0+)
# ---------------------------------------------------------------------------

class CausalSelfAttention(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        assert cfg.n_embd % cfg.n_head == 0, \
            "n_embd must be divisible by n_head"

        self.n_head   = cfg.n_head
        self.head_dim = cfg.n_embd // cfg.n_head
        self.n_embd   = cfg.n_embd
        self.dropout  = cfg.dropout

        # Fused QKV projection — one matrix instead of three saves memory
        self.c_attn   = nn.Linear(cfg.n_embd, 3 * cfg.n_embd, bias=cfg.bias)
        self.c_proj   = nn.Linear(cfg.n_embd, cfg.n_embd,     bias=cfg.bias)
        self.attn_drop = nn.Dropout(cfg.dropout)
        self.resid_drop = nn.Dropout(cfg.dropout)

    def forward(self, x: torch.Tensor,
                rope_freqs: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape

        # Project to Q, K, V
        qkv = self.c_attn(x)
        q, k, v = qkv.split(self.n_embd, dim=2)

        # Reshape to (B, n_head, T, head_dim)
        q = q.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        k = k.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        v = v.view(B, T, self.n_head, self.head_dim).transpose(1, 2)

        # Apply RoPE to Q and K (not V)
        q = apply_rope(q, rope_freqs)
        k = apply_rope(k, rope_freqs)

        # F.scaled_dot_product_attention handles causal masking automatically
        # with is_causal=True. On CUDA with PyTorch 2.0+, this dispatches to
        # FlashAttention-2 when available — no manual mask needed.
        attn_dropout = self.dropout if self.training else 0.0
        y = F.scaled_dot_product_attention(
            q, k, v,
            attn_mask=None,
            dropout_p=attn_dropout,
            is_causal=True,
        )

        # Reassemble: (B, n_head, T, head_dim) → (B, T, C)
        y = y.transpose(1, 2).contiguous().view(B, T, C)
        return self.resid_drop(self.c_proj(y))


# ---------------------------------------------------------------------------
# Feed-Forward Block (SwiGLU activation — better than GELU for small models)
# ---------------------------------------------------------------------------

class FeedForward(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        hidden = int(4 * cfg.n_embd * 2 / 3)   # SwiGLU hidden dim formula
        hidden = (hidden + 7) // 8 * 8           # round up to multiple of 8

        # SwiGLU: gate ⊗ SiLU(linear)
        self.w1 = nn.Linear(cfg.n_embd, hidden, bias=cfg.bias)
        self.w2 = nn.Linear(cfg.n_embd, hidden, bias=cfg.bias)
        self.w3 = nn.Linear(hidden, cfg.n_embd, bias=cfg.bias)
        self.drop = nn.Dropout(cfg.dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.drop(self.w3(F.silu(self.w1(x)) * self.w2(x)))


# ---------------------------------------------------------------------------
# Transformer Block
# ---------------------------------------------------------------------------

class Block(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.norm1 = RMSNorm(cfg.n_embd)
        self.attn  = CausalSelfAttention(cfg)
        self.norm2 = RMSNorm(cfg.n_embd)
        self.ff    = FeedForward(cfg)

    def forward(self, x: torch.Tensor,
                rope_freqs: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x), rope_freqs)  # pre-norm residual
        x = x + self.ff(self.norm2(x))
        return x


# ---------------------------------------------------------------------------
# Bengali GPT Model
# ---------------------------------------------------------------------------

class BengaliGPT(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.cfg = cfg

        self.transformer = nn.ModuleDict(dict(
            tok_emb = nn.Embedding(cfg.vocab_size, cfg.n_embd),
            drop    = nn.Dropout(cfg.dropout),
            blocks  = nn.ModuleList([Block(cfg) for _ in range(cfg.n_layer)]),
            norm_f  = RMSNorm(cfg.n_embd),
        ))
        self.lm_head = nn.Linear(cfg.n_embd, cfg.vocab_size, bias=False)

        # Weight tying: lm_head shares weights with token embedding.
        # Widely used since GPT-2 — reduces params and improves perplexity.
        self.transformer.tok_emb.weight = self.lm_head.weight

        # Precompute RoPE frequencies (stored as buffer, not parameter)
        rope_freqs = precompute_rope_freqs(
            cfg.n_embd // cfg.n_head, cfg.context_len)
        self.register_buffer("rope_freqs", rope_freqs)

        # Init weights
        self.apply(self._init_weights)
        # GPT-2 paper: scale residual projections by 1/sqrt(n_layer)
        for pn, p in self.named_parameters():
            if pn.endswith(('c_proj.weight', 'w3.weight')):
                nn.init.normal_(p, mean=0.0,
                                std=0.02 / math.sqrt(2 * cfg.n_layer))

        n_params = sum(p.numel() for p in self.parameters())
        print(f"BengaliGPT: {n_params/1e6:.2f}M parameters")

    def _init_weights(self, module: nn.Module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, idx: torch.Tensor,
                targets: torch.Tensor | None = None):
        """
        idx:     (B, T) int64 token indices
        targets: (B, T) int64 shifted targets (for training)
        Returns: (logits, loss) where loss is None if targets not provided
        """
        B, T = idx.shape
        assert T <= self.cfg.context_len, \
            f"Sequence length {T} exceeds context_len {self.cfg.context_len}"

        x = self.transformer.drop(self.transformer.tok_emb(idx))  # (B, T, C)

        for block in self.transformer.blocks:
            x = block(x, self.rope_freqs)

        x = self.transformer.norm_f(x)
        logits = self.lm_head(x)   # (B, T, vocab_size)

        if targets is not None:
            # Standard cross-entropy next-token prediction
            loss = F.cross_entropy(
                logits.view(-1, logits.size(-1)),
                targets.view(-1),
                ignore_index=-1,
            )
            return logits, loss

        return logits, None

    @torch.inference_mode()
    def generate(self, idx: torch.Tensor, max_new_tokens: int,
                 temperature: float = 0.85, top_p: float = 0.92,
                 eow_id: int | None = None) -> torch.Tensor:
        """
        Autoregressive generation with nucleus (top-p) sampling.
        Stops early if <|eow|> token is generated.
        """
        for _ in range(max_new_tokens):
            # Crop context to context_len if necessary
            idx_cond = idx[:, -self.cfg.context_len:]
            logits, _ = self(idx_cond)
            logits = logits[:, -1, :] / temperature   # (B, vocab_size)

            # Top-p (nucleus) sampling
            probs = F.softmax(logits, dim=-1)
            sorted_probs, sorted_idx = torch.sort(probs, descending=True)
            cumulative = torch.cumsum(sorted_probs, dim=-1)
            # Remove tokens with cumulative prob above top_p threshold
            sorted_probs[cumulative - sorted_probs > top_p] = 0.0
            sorted_probs /= sorted_probs.sum(dim=-1, keepdim=True)  # renorm
            next_token = sorted_idx.gather(
                -1, torch.multinomial(sorted_probs, 1))

            idx = torch.cat([idx, next_token], dim=1)

            if eow_id is not None and next_token.item() == eow_id:
                break

        return idx


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

class TokenDataset(Dataset):
    """
    Sliding-window dataset over a flat token array.
    Each item is (context, target) where target = context shifted by 1.
    """
    def __init__(self, token_path: str | Path, context_len: int):
        self.tokens      = np.load(str(token_path)).astype(np.int64)
        self.context_len = context_len
        # Number of full windows
        self.n = max(0, len(self.tokens) - context_len)

    def __len__(self) -> int:
        return self.n

    def __getitem__(self, idx: int):
        chunk = self.tokens[idx: idx + self.context_len + 1]
        x = torch.from_numpy(chunk[:-1].copy())
        y = torch.from_numpy(chunk[1:].copy())
        return x, y


# ---------------------------------------------------------------------------
# Learning Rate Schedule
# ---------------------------------------------------------------------------

def get_lr(step: int, tcfg: TrainConfig) -> float:
    """Warmup then cosine decay."""
    if step < tcfg.warmup_iters:
        return tcfg.learning_rate * step / tcfg.warmup_iters
    if step > tcfg.lr_decay_iters:
        return tcfg.min_lr
    # Cosine decay
    progress = (step - tcfg.warmup_iters) / (
        tcfg.lr_decay_iters - tcfg.warmup_iters)
    coeff = 0.5 * (1.0 + math.cos(math.pi * progress))
    return tcfg.min_lr + coeff * (tcfg.learning_rate - tcfg.min_lr)


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------

@torch.no_grad()
def estimate_loss(model: BengaliGPT, loaders: dict,
                  eval_iters: int, device: torch.device,
                  ctx) -> dict:
    model.eval()
    out = {}
    for split, loader in loaders.items():
        losses = []
        it = iter(loader)
        for _ in range(min(eval_iters, len(loader))):
            try:
                x, y = next(it)
            except StopIteration:
                break
            x, y = x.to(device), y.to(device)
            with ctx:
                _, loss = model(x, y)
            losses.append(loss.item())
        out[split] = float(np.mean(losses)) if losses else float('nan')
    model.train()
    return out


# ---------------------------------------------------------------------------
# Sample helper
# ---------------------------------------------------------------------------

def sample_text(model: BengaliGPT, sp, config: dict,
                device: torch.device, ctx,
                prompt_author: str | None = None) -> str:
    """Generate a sample, optionally conditioned on an author."""
    import sentencepiece as spm_module

    author_tokens = config.get("author_tokens", [])
    bow_id = config.get("bow_id")
    eow_id = config.get("eow_id")

    # Build prompt: <|bow|><|aut:X|>
    if prompt_author and author_tokens:
        # Pick a random author if none specified
        import random
        aut_tok = random.choice(author_tokens)
        aut_id  = sp.piece_to_id(aut_tok)
        prompt_ids = [bow_id, aut_id] if bow_id else [aut_id]
    else:
        prompt_ids = [bow_id] if bow_id else []

    if not prompt_ids:
        # Fallback: random token from vocab
        prompt_ids = [1]

    idx = torch.tensor([prompt_ids], dtype=torch.long, device=device)
    with ctx:
        out = model.generate(idx, max_new_tokens=150,
                             temperature=0.85, top_p=0.92, eow_id=eow_id)
    tokens = out[0].tolist()
    # Decode, skipping special token IDs
    special_ids = set(config.get("special_tokens", {}).values())
    content_ids = [t for t in tokens if t not in special_ids]
    return sp.decode(content_ids)


# ---------------------------------------------------------------------------
# Training Loop
# ---------------------------------------------------------------------------

def train(resume: bool = False):
    tcfg = TrainConfig()
    Path(tcfg.ckpt_dir).mkdir(exist_ok=True)

    # ---- Device & dtype setup -----------------------------------------------
    device = torch.device(
        "cuda" if torch.cuda.is_available() else
        "mps"  if torch.backends.mps.is_available() else "cpu"
    )
    print(f"Device: {device}")

    if tcfg.dtype == "auto":
        if device.type == "cuda":
            # bfloat16 on Ampere+ (compute capability 8.0+), else float16
            cc = torch.cuda.get_device_capability()
            dtype_str = "bfloat16" if cc[0] >= 8 else "float16"
        else:
            dtype_str = "float32"
    else:
        dtype_str = tcfg.dtype

    pt_dtype = {"float32": torch.float32,
                "float16": torch.float16,
                "bfloat16": torch.bfloat16}[dtype_str]
    print(f"Training dtype: {dtype_str}")

    # autocast context — no-op on CPU
    if device.type == "cuda":
        ctx = torch.amp.autocast(device_type="cuda", dtype=pt_dtype)
    else:
        ctx = torch.amp.autocast(device_type="cpu", dtype=torch.float32)

    # ---- Load tokenizer config -----------------------------------------------
    config_path = Path(tcfg.tok_dir) / "tokenizer_config.json"
    if not config_path.exists():
        raise FileNotFoundError(
            "tokenizer_config.json not found. Run steps 1-3 first.")
    tok_config = json.loads(config_path.read_text(encoding='utf-8'))

    import sentencepiece as spm_module
    sp = spm_module.SentencePieceProcessor()
    sp.load(tok_config["model_path"])

    # ---- Model config --------------------------------------------------------
    mcfg = ModelConfig(
        vocab_size  = tok_config["vocab_size"],
        context_len = 512,
        n_layer     = 6,
        n_head      = 6,
        n_embd      = 384,
        dropout     = 0.15,
    )

    # ---- Data ----------------------------------------------------------------
    data_dir = Path(tcfg.data_dir)
    train_ds = TokenDataset(data_dir / "train_tokens.npy", mcfg.context_len)
    val_ds   = TokenDataset(data_dir / "val_tokens.npy",   mcfg.context_len)
    print(f"Train tokens: {len(train_ds.tokens):,}  |  "
          f"Val tokens: {len(val_ds.tokens):,}")

    train_loader = DataLoader(
        train_ds, batch_size=tcfg.batch_size, shuffle=True,
        num_workers=2, pin_memory=(device.type == "cuda"),
        drop_last=True,
    )
    val_loader = DataLoader(
        val_ds, batch_size=tcfg.batch_size, shuffle=False,
        num_workers=0, drop_last=True,
    )
    loaders = {"train": train_loader, "val": val_loader}

    # ---- Model ---------------------------------------------------------------
    model = BengaliGPT(mcfg).to(device)

    # Compile for speed on PyTorch 2.x (optional — skip if causing issues)
    if device.type == "cuda" and hasattr(torch, "compile"):
        print("Compiling model with torch.compile()...")
        try:
            model = torch.compile(model)
        except Exception as e:
            print(f"  torch.compile() failed: {e}. Continuing without.")

    # ---- Optimizer -----------------------------------------------------------
    # Separate weight decay from bias / norm params
    decay_params = [p for n, p in model.named_parameters()
                    if p.requires_grad and p.dim() >= 2]
    nodecay_params = [p for n, p in model.named_parameters()
                      if p.requires_grad and p.dim() < 2]
    optim_groups = [
        {"params": decay_params,   "weight_decay": tcfg.weight_decay},
        {"params": nodecay_params, "weight_decay": 0.0},
    ]
    # Use fused AdamW on CUDA (PyTorch 2.x)
    fused = device.type == "cuda" and "fused" in str(
        torch.optim.AdamW.__init__.__doc__ or "")
    optimizer = torch.optim.AdamW(
        optim_groups, lr=tcfg.learning_rate, betas=(0.9, 0.95),
        fused=fused if fused else False,
    )

    # GradScaler for float16 (not needed for bfloat16)
    scaler = torch.amp.GradScaler(device=device.type,
                                  enabled=(dtype_str == "float16"))

    # ---- Resume from checkpoint ---------------------------------------------
    start_iter = 0
    best_val   = float("inf")
    patience_count = 0

    if resume:
        ckpt_files = sorted(Path(tcfg.ckpt_dir).glob("ckpt_iter*.pt"))
        if ckpt_files:
            latest = ckpt_files[-1]
            print(f"Resuming from {latest}")
            ckpt = torch.load(latest, map_location=device, weights_only=True)
            model.load_state_dict(ckpt["model"])
            optimizer.load_state_dict(ckpt["optimizer"])
            start_iter = ckpt["iter"]
            best_val   = ckpt.get("best_val", float("inf"))
            print(f"  Resumed at iter {start_iter}, best_val={best_val:.4f}")

    # ---- Training loop -------------------------------------------------------
    model.train()
    train_iter = iter(train_loader)
    t0 = time.time()

    print(f"\n{'='*60}")
    print(f"Starting training: {tcfg.max_iters} iters, "
          f"batch={tcfg.batch_size}, ctx={mcfg.context_len}")
    print(f"{'='*60}\n")

    for step in range(start_iter, tcfg.max_iters):
        # --- LR update
        lr = get_lr(step, tcfg)
        for pg in optimizer.param_groups:
            pg["lr"] = lr

        # --- Get batch (cycle through dataset)
        try:
            x, y = next(train_iter)
        except StopIteration:
            train_iter = iter(train_loader)
            x, y = next(train_iter)
        x, y = x.to(device), y.to(device)

        # --- Forward + backward
        optimizer.zero_grad(set_to_none=True)
        with ctx:
            _, loss = model(x, y)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), tcfg.grad_clip)
        scaler.step(optimizer)
        scaler.update()

        # --- Logging
        if step % 50 == 0:
            t1 = time.time()
            dt = (t1 - t0) / max(step - start_iter, 1)
            remaining = dt * (tcfg.max_iters - step) / 60
            print(f"iter {step:5d} | loss {loss.item():.4f} | "
                  f"lr {lr:.2e} | ~{remaining:.0f}min left")

        # --- Eval
        if step % tcfg.eval_interval == 0 and step > 0:
            losses = estimate_loss(model, loaders, tcfg.eval_iters,
                                   device, ctx)
            print(f"\n>>> Eval iter {step}: "
                  f"train={losses['train']:.4f}  val={losses['val']:.4f}")

            if losses["val"] < best_val:
                best_val = losses["val"]
                patience_count = 0
                # Save best checkpoint
                ckpt = {
                    "iter":      step,
                    "model":     model.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "best_val":  best_val,
                    "mcfg":      mcfg.__dict__,
                }
                torch.save(ckpt, Path(tcfg.ckpt_dir) / "ckpt_best.pt")
                print(f"    ✓ New best val loss: {best_val:.4f} — saved")
            else:
                patience_count += 1
                print(f"    No improvement ({patience_count}/{tcfg.patience})")
                if patience_count >= tcfg.patience:
                    print("\nEarly stopping triggered.")
                    break
            model.train()

        # --- Periodic checkpoint
        if step % tcfg.save_interval == 0 and step > 0:
            ckpt = {
                "iter":      step,
                "model":     model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "best_val":  best_val,
                "mcfg":      mcfg.__dict__,
            }
            torch.save(ckpt, Path(tcfg.ckpt_dir) / f"ckpt_iter{step:05d}.pt")

        # --- Sample text
        if step % tcfg.sample_interval == 0 and step > 0:
            print(f"\n--- Sample at iter {step} ---")
            text = sample_text(model, sp, tok_config, device, ctx)
            print(text[:400])
            print("---\n")
            model.train()

    print(f"\nTraining complete. Best val loss: {best_val:.4f}")
    print(f"Best checkpoint: {tcfg.ckpt_dir}/ckpt_best.pt")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--resume", action="store_true",
                        help="Resume from latest checkpoint")
    args = parser.parse_args()
    train(resume=args.resume)

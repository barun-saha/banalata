"""
Step 5: Generate Bengali Text
==============================
Load a trained checkpoint and generate text, optionally conditioning
on a specific author or completing a given prompt.

Usage:
    # Generate with a random author
    python 05_generate.py

    # Generate conditioned on a specific author
    python 05_generate.py --author "রবীন্দ্রনাথ"

    # Complete a given Bengali prompt
    python 05_generate.py --prompt "আকাশ ভরা সূর্য তারা"

    # Interactive mode
    python 05_generate.py --interactive

    # Show all available authors
    python 05_generate.py --list-authors
"""

import argparse
import json
from pathlib import Path

import torch

# Import model definition from training script
import sys
sys.path.insert(0, str(Path(__file__).parent))
from train_model_04 import BengaliGPT, ModelConfig   # rename if needed


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
CKPT_PATH = "checkpoints/ckpt_best.pt"
TOK_DIR   = Path("tokenizer")


def load_model_and_tokenizer(ckpt_path: str, device: torch.device):
    """Load checkpoint, reconstruct model, load tokenizer."""
    import sentencepiece as spm

    # Load tokenizer config
    tok_config = json.loads(
        (TOK_DIR / "tokenizer_config.json").read_text(encoding='utf-8'))
    sp = spm.SentencePieceProcessor()
    sp.load(tok_config["model_path"])

    # Load checkpoint
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=True)
    mcfg_dict = ckpt["mcfg"]
    mcfg = ModelConfig(**mcfg_dict)

    model = BengaliGPT(mcfg).to(device)
    # Handle torch.compile() prefix if present
    state = ckpt["model"]
    state = {k.replace("_orig_mod.", ""): v for k, v in state.items()}
    model.load_state_dict(state)
    model.eval()

    print(f"Loaded checkpoint (iter={ckpt.get('iter', '?')}, "
          f"val_loss={ckpt.get('best_val', '?'):.4f})")
    return model, sp, tok_config


@torch.inference_mode()
def generate(
    model: BengaliGPT,
    sp,
    tok_config: dict,
    device: torch.device,
    author: str | None = None,
    prompt: str | None = None,
    max_tokens: int = 300,
    temperature: float = 0.85,
    top_p: float = 0.92,
    n_samples: int = 1,
) -> list[str]:
    """
    Generate text samples.

    Prompt construction priority:
      1. If `prompt` given: encode it directly (ignores author)
      2. If `author` given: <|bow|><|aut:author|>
      3. Otherwise: <|bow|> only
    """
    bow_id = tok_config.get("bow_id")
    eow_id = tok_config.get("eow_id")
    special_ids = set(tok_config.get("special_tokens", {}).values())

    results = []

    # Use autocast for speed even at inference
    if device.type == "cuda":
        ctx = torch.amp.autocast(device_type="cuda", dtype=torch.bfloat16)
    else:
        ctx = torch.amp.autocast(device_type="cpu", dtype=torch.float32)

    for _ in range(n_samples):
        if prompt:
            # Encode user's prompt directly
            prompt_ids = sp.encode(prompt, out_type=int)
            if bow_id:
                prompt_ids = [bow_id] + prompt_ids
        elif author:
            # Author-conditioned generation
            aut_tok = f"<|aut:{author}|>"
            aut_id  = sp.piece_to_id(aut_tok)
            if aut_id == sp.unk_id():
                # Try to find a close match
                available = tok_config.get("author_tokens", [])
                matches = [t for t in available if author in t]
                if matches:
                    aut_tok = matches[0]
                    aut_id  = sp.piece_to_id(aut_tok)
                    print(f"Using author token: {aut_tok}")
                else:
                    print(f"Author '{author}' not found. "
                          f"Using <|bow|> only.")
                    aut_id = None
            prompt_ids = [bow_id, aut_id] if (bow_id and aut_id) else \
                         [bow_id] if bow_id else []
        else:
            prompt_ids = [bow_id] if bow_id else []

        if not prompt_ids:
            prompt_ids = [sp.bos_id()]

        idx = torch.tensor([prompt_ids], dtype=torch.long, device=device)
        with ctx:
            out = model.generate(
                idx, max_new_tokens=max_tokens,
                temperature=temperature, top_p=top_p,
                eow_id=eow_id,
            )
        tokens = out[0].tolist()

        # Decode: skip special tokens, keep content
        content_ids = [t for t in tokens if t not in special_ids]
        text = sp.decode(content_ids)
        results.append(text.strip())

    return results


def list_authors(tok_config: dict):
    """Print all available author conditioning tokens."""
    tokens = tok_config.get("author_tokens", [])
    print(f"\nAvailable author tokens ({len(tokens)}):")
    for t in sorted(tokens):
        # Extract author name from <|aut:NAME|>
        name = t.replace("<|aut:", "").replace("|>", "")
        print(f"  --author \"{name}\"")


def interactive_mode(model, sp, tok_config, device):
    """REPL for interactive generation."""
    print("\n" + "="*55)
    print("Bengali GPT — Interactive Mode")
    print("Commands:")
    print("  [Enter] alone       — generate with random author")
    print("  author: NAME        — set author (Bengali name)")
    print("  prompt: TEXT        — set Bengali prompt text")
    print("  temp: 0.8           — set temperature (default 0.85)")
    print("  top_p: 0.9          — set top-p (default 0.92)")
    print("  tokens: 200         — set max output tokens")
    print("  authors             — list available authors")
    print("  quit                — exit")
    print("="*55 + "\n")

    import random
    author    = None
    prompt    = None
    temp      = 0.85
    top_p     = 0.92
    max_tokens = 250

    while True:
        try:
            cmd = input(">>> ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if cmd.lower() in ("quit", "exit", "q"):
            break
        elif cmd.lower() == "authors":
            list_authors(tok_config)
        elif cmd.lower().startswith("author:"):
            author = cmd.split(":", 1)[1].strip()
            prompt = None
            print(f"Author set to: {author}")
        elif cmd.lower().startswith("prompt:"):
            prompt = cmd.split(":", 1)[1].strip()
            author = None
            print(f"Prompt set to: {prompt}")
        elif cmd.lower().startswith("temp:"):
            temp = float(cmd.split(":", 1)[1].strip())
            print(f"Temperature: {temp}")
        elif cmd.lower().startswith("top_p:"):
            top_p = float(cmd.split(":", 1)[1].strip())
            print(f"Top-p: {top_p}")
        elif cmd.lower().startswith("tokens:"):
            max_tokens = int(cmd.split(":", 1)[1].strip())
            print(f"Max tokens: {max_tokens}")
        elif cmd == "":
            # Generate
            if author is None and prompt is None:
                # Pick random author for variety
                tokens = tok_config.get("author_tokens", [])
                if tokens:
                    tok  = random.choice(tokens)
                    author = tok.replace("<|aut:", "").replace("|>", "")
                    print(f"(Random author: {author})")

            results = generate(
                model, sp, tok_config, device,
                author=author, prompt=prompt,
                max_tokens=max_tokens,
                temperature=temp, top_p=top_p,
            )
            print(f"\n{'-'*50}")
            print(results[0])
            print(f"{'-'*50}\n")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Bengali GPT Text Generation")
    parser.add_argument("--ckpt",         default=CKPT_PATH)
    parser.add_argument("--author",       default=None,
                        help="Bengali author name, e.g. 'রবীন্দ্রনাথ'")
    parser.add_argument("--prompt",       default=None,
                        help="Bengali text prompt to continue")
    parser.add_argument("--max-tokens",   type=int, default=300)
    parser.add_argument("--temperature",  type=float, default=0.85)
    parser.add_argument("--top-p",        type=float, default=0.92)
    parser.add_argument("--n-samples",    type=int, default=1)
    parser.add_argument("--interactive",  action="store_true")
    parser.add_argument("--list-authors", action="store_true")
    args = parser.parse_args()

    device = torch.device(
        "cuda" if torch.cuda.is_available() else
        "mps"  if torch.backends.mps.is_available() else "cpu"
    )

    model, sp, tok_config = load_model_and_tokenizer(args.ckpt, device)

    if args.list_authors:
        list_authors(tok_config)
        return

    if args.interactive:
        interactive_mode(model, sp, tok_config, device)
        return

    # Single generation
    results = generate(
        model, sp, tok_config, device,
        author=args.author,
        prompt=args.prompt,
        max_tokens=args.max_tokens,
        temperature=args.temperature,
        top_p=args.top_p,
        n_samples=args.n_samples,
    )

    for i, text in enumerate(results):
        if args.n_samples > 1:
            print(f"\n--- Sample {i+1} ---")
        print(text)


if __name__ == "__main__":
    main()

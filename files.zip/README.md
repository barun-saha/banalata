# Bengali GPT — From-Scratch Language Model on Bangla Sahitya

A decoder-only transformer trained from scratch on public-domain Bengali
literary text, spanning the 8th–20th centuries.

---

## Architecture at a glance

| Component          | Choice                              | Why                                        |
|--------------------|-------------------------------------|--------------------------------------------|
| Model type         | Decoder-only GPT                    | Proven for text generation; nanoGPT lineage|
| Params             | ~12M                                | Fits data size; trains in 2–3h on one GPU  |
| Positional enc.    | RoPE                                | Better length generalization than learned  |
| Normalization      | RMSNorm                             | Faster, no bias, numerically stable        |
| Activation         | SwiGLU                              | Better gradient flow than GELU for small models |
| Attention          | F.scaled_dot_product_attention      | Auto-dispatches to FlashAttention on CUDA  |
| Tokenizer          | SentencePiece BPE, vocab=5000       | Learns Bengali syllable clusters natively  |
| Conditioning       | `<|bow|><|aut:AUTHOR|>` prefix      | Clean author-conditioning without metadata noise |

---

## Setup

```bash
# Python 3.10+
pip install torch==2.11.0 sentencepiece==0.2.1 datasets==3.5.0 numpy
```

---

## Pipeline (run in order)

```bash
# 1. Download dataset, clean Bengali text, format with author tokens
python 01_prepare_data.py

# 2. Train BPE tokenizer on the cleaned corpus
python 02_train_tokenizer.py

# 3. Encode corpus to token arrays (memory-mapped .npy files)
python 03_encode_data.py

# 4. Train the model (2–3 hours on a single GPU)
python 04_train_model.py

# Resume after interruption:
python 04_train_model.py --resume

# 5. Generate text
python 05_generate.py --author "রবীন্দ্রনাথ"
python 05_generate.py --prompt "আকাশ ভরা সূর্য তারা"
python 05_generate.py --interactive
python 05_generate.py --list-authors
```

---

## Data format (what the model actually sees)

Each work in the training corpus looks like:

```
<|bow|><|aut:রবীন্দ্রনাথ|>
আমার সোনার বাংলা আমি তোমায় ভালোবাসি
চিরদিন তোমার আকাশ তোমার বাতাস আমার প্রাণে বাজায় বাঁশি।
...
<|eow|>
```

At inference, you prime the model with `<|bow|><|aut:X|>` and it generates
X's literary style until it produces `<|eow|>`.

**Why not include title/author name as text?**
Previous approaches embedded the author name as plain text. The model then
wasted capacity learning to predict the author name rather than the literary
content. Special tokens are learned as discrete conditioning signals instead.

---

## Tuning guidance

### If val loss diverges early from train loss (overfitting):
- Increase `dropout` from 0.15 → 0.20–0.25
- Reduce model size: `n_layer=4`, `n_embd=256`
- Add weight decay: increase `weight_decay` to 0.15

### If both losses plateau high (underfitting):
- Your vocab_size may be too large — retrain tokenizer with `VOCAB_SIZE=3000`
- Reduce context_len to 256 (shorter sequences = more gradient updates/epoch)
- Check that Bengali text is actually in the corpus (run 01_prepare_data.py
  and inspect `data/train.txt`)

### If generated text is incoherent gibberish from the start:
- Inspect tokenizer output: run 02_train_tokenizer.py and check that
  SentencePiece produces meaningful Bengali subwords, not individual chars
- Check your total token count in 03_encode_data.py — if train tokens < 500K,
  the corpus is too small for this vocab size

### If generation is fluent but boring / repetitive:
- Increase temperature: 0.85 → 1.0
- Increase top_p: 0.92 → 0.95
- These trade coherence for diversity

### Expected training behavior:
```
iter    0: loss ~8.5  (random, ~log(5000))
iter  500: loss ~4.0  (learning Bengali subword patterns)
iter 2000: loss ~3.0  (learning word-level structure)
iter 5000: loss ~2.4  (learning literary phrases)
iter 10000: loss ~2.0–2.2 (good — diminishing returns beyond this)
```
If loss is not decreasing after 1000 iterations, something is wrong with
data loading or tokenization — do not train further.

---

## Author conditioning: which authors work best?

Authors with the most text in the corpus will have the strongest conditioning
signal. Run `python 01_prepare_data.py` and check the per-author char counts.
Authors with < 2000 chars are pooled into `<|aut:অজ্ঞাত|>`.

Authors likely to have strong conditioning (from the dataset):
- রবীন্দ্রনাথ ঠাকুর (Rabindranath Tagore) — largest corpus
- কাজী নজরুল ইসলাম (Kazi Nazrul Islam)
- বঙ্কিমচন্দ্র চট্টোপাধ্যায় (Bankim Chandra)
- শরৎচন্দ্র চট্টোপাধ্যায় (Sarat Chandra)

---

## Files produced

```
data/
  train.txt               cleaned training corpus
  val.txt                 validation corpus
  test.txt                held-out test corpus
  tokenizer_corpus.txt    train+val for tokenizer training
  author_tokens.txt       list of <|aut:...|> tokens
  train_tokens.npy        encoded train tokens (uint16)
  val_tokens.npy          encoded val tokens
  test_tokens.npy         encoded test tokens

tokenizer/
  bengali_bpe.model       SentencePiece model
  bengali_bpe.vocab       human-readable vocab
  tokenizer_config.json   IDs for special tokens

checkpoints/
  ckpt_best.pt            best checkpoint (lowest val loss)
  ckpt_iter*.pt           periodic checkpoints
```

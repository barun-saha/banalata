"""
Step 1: Data Preparation
========================
Downloads the bangla_sahitya dataset, cleans it, removes English/noise,
and writes a training corpus with author-conditioning tokens.

Requirements:
    pip install datasets==3.5.0 sentencepiece==0.2.1

Usage:
    python 01_prepare_data.py
"""

import re
import unicodedata
from pathlib import Path
from collections import defaultdict

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
OUTPUT_DIR = Path("data")
OUTPUT_DIR.mkdir(exist_ok=True)

# Special tokens — used as conditioning signals and boundaries
TOK_BOW   = "<|bow|>"    # beginning of work
TOK_EOW   = "<|eow|>"    # end of work
TOK_AUT   = "<|aut:{name}|>"  # author token template (filled at runtime)
MIN_WORK_CHARS = 150     # discard works shorter than this (titles, fragments)
MIN_AUTHOR_CHARS = 2000  # authors with less total text get pooled as <|aut:অজ্ঞাত|>

# ---------------------------------------------------------------------------
# Bengali Unicode ranges
# ---------------------------------------------------------------------------
BENGALI_BLOCK       = (0x0980, 0x09FF)   # Bengali script
BENGALI_PUNCTUATION = set("।৷॥,।!?;:\"'()[]{}…—–-\n ")
LATIN_RE = re.compile(r'[A-Za-z]{3,}')  # 3+ consecutive Latin chars → English


def is_mostly_bengali(text: str, threshold: float = 0.5) -> bool:
    """Return True if >= threshold fraction of non-space chars are Bengali."""
    chars = [c for c in text if not c.isspace()]
    if not chars:
        return False
    bengali = sum(
        1 for c in chars
        if BENGALI_BLOCK[0] <= ord(c) <= BENGALI_BLOCK[1]
        or c in BENGALI_PUNCTUATION
    )
    return (bengali / len(chars)) >= threshold


def remove_english_lines(text: str) -> str:
    """Drop lines that are predominantly English."""
    lines = text.split('\n')
    kept = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            kept.append(line)
            continue
        # If line has long English words, skip it
        if LATIN_RE.search(stripped):
            latin_chars = sum(1 for c in stripped if c.isascii() and c.isalpha())
            total_alpha = sum(1 for c in stripped if c.isalpha())
            if total_alpha > 0 and (latin_chars / total_alpha) > 0.4:
                continue
        kept.append(line)
    return '\n'.join(kept)


def clean_text(text: str) -> str:
    """
    Clean a single work's text:
    - Normalize unicode (NFC — important for Bengali matras)
    - Remove English-heavy lines
    - Remove excessive whitespace
    - Remove control characters
    """
    # NFC normalization — critical for Bengali: ensures vowel marks
    # (matras) are combined with their base consonants consistently
    text = unicodedata.normalize('NFC', text)

    # Remove English-heavy lines
    text = remove_english_lines(text)

    # Remove control chars except newline/tab
    text = ''.join(c for c in text if unicodedata.category(c) != 'Cc'
                   or c in '\n\t')

    # Collapse 3+ consecutive newlines to 2 (preserve stanza breaks)
    text = re.sub(r'\n{3,}', '\n\n', text)

    # Collapse horizontal whitespace
    text = re.sub(r'[ \t]+', ' ', text)

    # Strip leading/trailing whitespace per line
    text = '\n'.join(line.strip() for line in text.split('\n'))

    return text.strip()


def extract_content(raw: str) -> str:
    """
    The dataset stores works as:
        Title (line 1, often)
        Author name (line 2, often)
        blank line
        content...

    We want ONLY the literary content, not metadata lines.
    Heuristic: drop leading lines that are short (< 60 chars) and appear
    before the first blank line or first content paragraph.
    """
    lines = raw.split('\n')
    # Find first "content" line: not too short, not just an author name
    content_start = 0
    for i, line in enumerate(lines[:6]):   # check only first 6 lines
        stripped = line.strip()
        # Skip blank lines
        if not stripped:
            content_start = i + 1
            continue
        # Skip short lines (likely title / author name)
        if len(stripped) < 55:
            content_start = i + 1
    return '\n'.join(lines[content_start:]).strip()


def format_work(author_token: str, content: str) -> str:
    """
    Final on-disk format for a single work:

        <|bow|><|aut:রবীন্দ্রনাথ|>
        content of the work...
        <|eow|>

    The model learns: after seeing <|bow|><|aut:X|>, produce X's style.
    """
    return f"{TOK_BOW}{author_token}\n{content}\n{TOK_EOW}"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    print("Loading dataset from HuggingFace...")
    from datasets import load_dataset
    ds = load_dataset("barunsaha/bangla_sahitya", split="train")
    df = ds.to_pandas()
    print(f"Loaded {len(df)} rows, {df['author'].nunique()} unique authors")

    # ---- Pass 1: clean all works, compute per-author char counts ----------
    author_total_chars: defaultdict = defaultdict(int)
    cleaned_works = []   # list of (author, cleaned_content)

    skipped = 0
    for _, row in df.iterrows():
        author = str(row['author']).strip()
        raw    = str(row['text'])

        content = extract_content(raw)
        content = clean_text(content)

        if len(content) < MIN_WORK_CHARS:
            skipped += 1
            continue
        if not is_mostly_bengali(content):
            skipped += 1
            continue

        author_total_chars[author] += len(content)
        cleaned_works.append((author, content))

    print(f"Kept {len(cleaned_works)} works, skipped {skipped}")
    print(f"\nPer-author character counts:")
    for auth, cnt in sorted(author_total_chars.items(), key=lambda x: -x[1]):
        marker = "  ✓" if cnt >= MIN_AUTHOR_CHARS else "  (pooled→অজ্ঞাত)"
        print(f"  {auth}: {cnt:,}{marker}")

    # ---- Pass 2: assign author tokens, pool small authors -----------------
    small_authors = {a for a, c in author_total_chars.items()
                     if c < MIN_AUTHOR_CHARS}
    print(f"\n{len(small_authors)} authors pooled into <|aut:অজ্ঞাত|> "
          f"(< {MIN_AUTHOR_CHARS} chars)")

    formatted_works = []
    for author, content in cleaned_works:
        eff_author = "অজ্ঞাত" if author in small_authors else author
        aut_tok = TOK_AUT.format(name=eff_author)
        formatted_works.append(format_work(aut_tok, content))

    # ---- Split by works (not by chars) ------------------------------------
    import random
    random.seed(42)
    random.shuffle(formatted_works)

    n_val   = max(1, int(len(formatted_works) * 0.05))
    n_test  = max(1, int(len(formatted_works) * 0.05))
    n_train = len(formatted_works) - n_val - n_test

    train_works = formatted_works[:n_train]
    val_works   = formatted_works[n_train:n_train + n_val]
    test_works  = formatted_works[n_train + n_val:]

    # Join with double newline between works (extra breathing room)
    sep = "\n\n"
    train_corpus = sep.join(train_works)
    val_corpus   = sep.join(val_works)
    test_corpus  = sep.join(test_works)

    # ---- Write to disk ----------------------------------------------------
    (OUTPUT_DIR / "train.txt").write_text(train_corpus, encoding='utf-8')
    (OUTPUT_DIR / "val.txt").write_text(val_corpus,   encoding='utf-8')
    (OUTPUT_DIR / "test.txt").write_text(test_corpus, encoding='utf-8')

    # Tokenizer trains on train+val (not test — keep it unseen)
    tokenizer_corpus = train_corpus + "\n\n" + val_corpus
    (OUTPUT_DIR / "tokenizer_corpus.txt").write_text(
        tokenizer_corpus, encoding='utf-8')

    # ---- Write list of author tokens for later use -----------------------
    unique_effective_authors = set()
    for author, _ in cleaned_works:
        eff = "অজ্ঞাত" if author in small_authors else author
        unique_effective_authors.add(eff)

    author_tokens = sorted(
        [TOK_AUT.format(name=a) for a in unique_effective_authors])
    (OUTPUT_DIR / "author_tokens.txt").write_text(
        '\n'.join(author_tokens), encoding='utf-8')

    # ---- Summary ----------------------------------------------------------
    print(f"\n{'='*55}")
    print(f"Train: {len(train_works)} works  |  {len(train_corpus):,} chars")
    print(f"Val:   {len(val_works)} works  |  {len(val_corpus):,} chars")
    print(f"Test:  {len(test_works)} works  |  {len(test_corpus):,} chars")
    print(f"Unique effective authors: {len(unique_effective_authors)}")
    print(f"\nFiles written to: {OUTPUT_DIR.resolve()}")
    print(f"  train.txt, val.txt, test.txt")
    print(f"  tokenizer_corpus.txt  (train+val, for SPM training)")
    print(f"  author_tokens.txt     (list of <|aut:...|> tokens)")
    print(f"\nNext step: python 02_train_tokenizer.py")


if __name__ == "__main__":
    main()

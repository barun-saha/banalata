"""
Step 2: Train SentencePiece BPE Tokenizer
==========================================
Trains a BPE tokenizer on the Bengali corpus.
Vocab size ~5000 is the sweet spot for this dataset:
  - Large enough to cover common Bengali syllable clusters
  - Small enough that each token gets adequate training signal

Requirements:
    pip install sentencepiece==0.2.1

Usage:
    python 02_train_tokenizer.py
"""

import json
from pathlib import Path
import sentencepiece as spm

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
DATA_DIR  = Path("data")
TOK_DIR   = Path("tokenizer")
TOK_DIR.mkdir(exist_ok=True)

VOCAB_SIZE = 5000          # tune down to 3000 if corpus < 3M chars
SPM_PREFIX = str(TOK_DIR / "bengali_bpe")

# Special tokens — must match 01_prepare_data.py
SPECIAL_TOKENS = [
    "<|bow|>",   # beginning of work
    "<|eow|>",   # end of work
    "<|pad|>",   # padding
]

# Author tokens are loaded dynamically so tokenizer covers all of them
def load_author_tokens() -> list[str]:
    path = DATA_DIR / "author_tokens.txt"
    if not path.exists():
        print("WARNING: author_tokens.txt not found. Run 01_prepare_data.py first.")
        return []
    return [t.strip() for t in path.read_text(encoding='utf-8').splitlines()
            if t.strip()]


def train_tokenizer():
    corpus_path = DATA_DIR / "tokenizer_corpus.txt"
    if not corpus_path.exists():
        raise FileNotFoundError(
            "tokenizer_corpus.txt not found. Run 01_prepare_data.py first.")

    corpus_text = corpus_path.read_text(encoding='utf-8')
    total_chars = len(corpus_text)
    print(f"Corpus size: {total_chars:,} characters")

    if total_chars < 500_000:
        print("WARNING: corpus is small (<500K chars). "
              "Consider reducing VOCAB_SIZE to 2000-3000.")

    author_tokens = load_author_tokens()
    all_special = SPECIAL_TOKENS + author_tokens
    print(f"Special tokens: {len(all_special)} "
          f"({len(SPECIAL_TOKENS)} reserved + {len(author_tokens)} author)")

    # SentencePiece needs special tokens as a comma-separated string
    user_defined = ','.join(all_special)

    print(f"\nTraining BPE tokenizer (vocab_size={VOCAB_SIZE})...")
    spm.SentencePieceTrainer.train(
        input=str(corpus_path),
        model_prefix=SPM_PREFIX,
        vocab_size=VOCAB_SIZE,
        model_type='bpe',

        # Bengali coverage: 0.9999 captures rare chars like Vedic extensions
        character_coverage=0.9999,

        # Reserved IDs — keep 0-3 for pad/unk/bos/eos even though we use
        # our own special tokens; SPM requires these slots.
        pad_id=0,
        unk_id=1,
        bos_id=2,
        eos_id=3,

        # Our special tokens get IDs starting at 4
        user_defined_symbols=user_defined,

        # Don't let SPM lowercase or normalize — Bengali case doesn't apply,
        # but normalization can mangle matras (vowel marks)
        normalization_rule_name='nmt_nfkc',

        # Shuffle for BPE stability
        input_sentence_size=1_000_000,
        shuffle_input_sentence=True,

        # Keep whitespace handling consistent — the ▁ prefix marks
        # word-initial position, which helps with Bengali word boundaries
        add_dummy_prefix=True,
        remove_extra_whitespaces=True,

        # Training verbosity
        train_extremely_large_corpus=False,
    )
    print(f"Tokenizer saved: {SPM_PREFIX}.model + {SPM_PREFIX}.vocab")


def verify_and_save_config():
    """Load the trained tokenizer, run sanity checks, save a config JSON."""
    sp = spm.SentencePieceProcessor()
    sp.load(f"{SPM_PREFIX}.model")

    actual_vocab = sp.get_piece_size()
    print(f"\nActual vocab size: {actual_vocab}")

    # Verify special tokens are present and have stable IDs
    author_tokens = load_author_tokens()
    all_special = SPECIAL_TOKENS + author_tokens
    special_ids = {}
    for tok in all_special:
        tid = sp.piece_to_id(tok)
        if tid == sp.unk_id():
            print(f"  WARNING: {tok!r} not found in vocab (mapped to UNK)")
        else:
            special_ids[tok] = tid

    print(f"Special token IDs (sample):")
    for tok in (SPECIAL_TOKENS + author_tokens[:3]):
        print(f"  {tok!r}  →  {special_ids.get(tok, 'NOT FOUND')}")

    # Encoding test
    samples = [
        "আমার সোনার বাংলা আমি তোমায় ভালোবাসি",
        "বিদ্রোহী রণক্লান্ত আমি সেই দিন হব শান্ত",
        "আলো আমার আলো ওগো আলো ভুবন ভরা",
    ]
    print(f"\nTokenization examples:")
    for s in samples:
        pieces = sp.encode(s, out_type=str)
        ids    = sp.encode(s, out_type=int)
        decoded = sp.decode(ids)
        rt_ok = "✓" if decoded == s else f"✗ (got: {decoded!r})"
        print(f"  Input:   {s}")
        print(f"  Pieces:  {pieces}")
        print(f"  IDs:     {ids}")
        print(f"  RT:      {rt_ok}")
        print()

    # Save tokenizer config for model to load
    config = {
        "model_path": f"{SPM_PREFIX}.model",
        "vocab_size": actual_vocab,
        "special_tokens": special_ids,
        "bow_token": "<|bow|>",
        "eow_token": "<|eow|>",
        "pad_token": "<|pad|>",
        "pad_id": special_ids.get("<|pad|>", 0),
        "bow_id": special_ids.get("<|bow|>"),
        "eow_id": special_ids.get("<|eow|>"),
        "author_tokens": author_tokens,
    }
    config_path = TOK_DIR / "tokenizer_config.json"
    config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2),
                           encoding='utf-8')
    print(f"Tokenizer config saved: {config_path}")
    return config


def main():
    train_tokenizer()
    config = verify_and_save_config()

    print(f"\n{'='*55}")
    print(f"Tokenizer training complete!")
    print(f"Vocab size:       {config['vocab_size']}")
    print(f"<|bow|> ID:       {config['bow_id']}")
    print(f"<|eow|> ID:       {config['eow_id']}")
    print(f"Author tokens:    {len(config['author_tokens'])}")
    print(f"\nNext step: python 03_encode_data.py")


if __name__ == "__main__":
    main()
